from constantes import *
from main import *

def estaEnTablero(x, y):
    return

def estadoLineaCompleta(tablero, y):
    return

def removerLineaCompleta(tablero):
    return

def obtenerTableroEnBlanco():
    return

def obtenerNuevaPieza():
    return

def esPosicionValida(tablero, pieza, adjX=0, adjY=0):
    return

def agregarTablero(tablero, pieza):
